/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ecommercesystem;

/**
 *
 * @author LENOVO
 */
public class Cart {
    private int customerId;
    private int nProducts;
    private int element = 0;
    private Product[]products;

    Cart(int customerId, int nProducts) {
    this.customerId = Math.abs(customerId);
    this.nProducts = nProducts;
    this.products = new Product[nProducts];
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public void setnProducts(int nProducts) {
        this.nProducts = nProducts;
    }

    public void setElement(int element) {
        this.element = element;
    }

    public void setProducts(Product[] products) {
        this.products = products;
    }

    public int getCustomerId() {
        return customerId;
    }

    public int getnProducts() {
        return nProducts;
    }

    public int getElement() {
        return element;
    }

    public Product[] getProducts() {
        return products;
    }
    public void addProduct(Product product){
    products[this.element] = product;
    this.element++;
    
    }
    
    public void removeProduct(int index){
    if (index >= 0 && index < nProducts){
     
    for (int i = index; i < nProducts - 1; i++) {
    products[i] = products[i + 1];
    }
    nProducts--;
    products[nProducts] = null; 
    }else{
    System.out.println("Invalid product index!");
     }
    }
    
    public float calculatePrice(){
    float totalPrice = 0;
    for(int i = 0; i < nProducts; i++){
    totalPrice += products[i].getPrice();
    }
    return totalPrice;
    }
    
    public void placeOrder(){
    Order order = new Order(customerId , 1 , products , (float)calculatePrice());
    order.printOrderInfo();
    }

    
    
}
