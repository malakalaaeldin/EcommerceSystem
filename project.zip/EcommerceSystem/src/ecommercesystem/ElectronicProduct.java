/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ecommercesystem;

/**
 *
 * @author LENOVO
 */
public class ElectronicProduct extends Product{
     private String brand;
    private int warrantyPeriod;

    ElectronicProduct(String brand, int warrantyPeriod, int productId, String name, float price){
    super(productId, name, price);
    this.brand = brand;
    this.warrantyPeriod =Math.abs(warrantyPeriod);
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public void setWarrantyPeriod(int warrantyPeriod) {
        this.warrantyPeriod = warrantyPeriod;
    }

    public String getBrand() {
        return brand;
    }

    public int getWarrantyPeriod() {
        return warrantyPeriod;
    }
    

   
    
    
}

