/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ecommercesystem;
import java.util.Scanner;
import javax.swing.SwingUtilities;

/**
 *
 * @author LENOVO
 */
public class EcommerceSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
        
        ElectronicProduct electronicProduct = new ElectronicProduct("Samsung", 1 , 1 , "smartphone" , (float)599.9);
        ClothingProduct clothingProduct = new ClothingProduct("Medium" , "Cotton" , 2 , "T-shirt" , (float)19.99 );
        BookProduct bookProduct = new BookProduct("O’Reilly" , "X Publications" , 3 , "OOP" , (float)39.99);
        
        
        // Create customer
        System.out.print("Enter your customer ID: ");
        int customerId = scanner.nextInt();
        System.out.print("Enter your name: ");
        String customerName = scanner.nextLine();
        scanner.nextLine(); // Consume extra newline character
        System.out.print("Enter your address: ");
        String customerAddress = scanner.nextLine();
        Customer customer = new Customer(customerId, customerName, customerAddress);
        
        System.out.println("How many products you want to add to your cart? ");
        int itemsnum = scanner.nextInt();
        Cart cart = new Cart(customerId , itemsnum);
        
        for(int i = 0; i<itemsnum; i++){
        System.out.println("Which product you would like to add? 1- Smartphone 2- T-shirt 3- OOP ");
        int choice = scanner.nextInt();
        switch(choice){
            case 1 :
                cart.addProduct(electronicProduct);
                break;
            case 2 :
                cart.addProduct(clothingProduct);
                break;
            case 3 :
                cart.addProduct(bookProduct);
                break;                
            default :
                System.out.println("Unavailable option");
         }
        }    
        
        System.out.print("The total is $" + cart.calculatePrice() + " ");
        System.out.println("Would you like to place the order? 1- Yes 2- No");
        int option = scanner.nextInt();
        switch(option){
            case 1 : 
              cart.placeOrder();
              break;
            case 2 :
                System.out.println("Thank you");
                break;
            default :
               System.out.println("Unavailable option"); 
        }
       
        
    }
    SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new EcommerrceGUI().setVisible(true);
            }
        })
    
}
