/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ecommercesystem;

/**
 *
 * @author LENOVO
 */
public class Order {
     private int customerId;
    private int orderId;
    private Product[]products;
    private float totalPrice;

    Order(int customerId, int orderId, Product[] products, float totalPrice){
    this.customerId = Math.abs(customerId);
    this.orderId = Math.abs(orderId);
    this.products = products;
    this.totalPrice = Math.abs(totalPrice);
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public void setProducts(Product[] products) {
        this.products = products;
    }

    public void setTotalPrice(float totalPrice) {
        this.totalPrice = totalPrice;
    }

    public int getCustomerId() {
        return customerId;
    }

    public int getOrderId() {
        return orderId;
    }

    public Product[] getProducts() {
        return products;
    }

    public float getTotalPrice() {
        return totalPrice;
    }
     public void printOrderInfo(){
    System.out.println("Here's your order's summary:");
    System.out.println("Order ID: " + orderId);
    System.out.println("Customer ID: " + customerId);
    System.out.println("Products: " );
    for(int i = 0 ; i< products.length ; i++){
    System.out.println(products[i].getName() + " - " + products[i].getPrice());
     }
    System.out.println("Total price: $" + totalPrice);
    }
    
}
